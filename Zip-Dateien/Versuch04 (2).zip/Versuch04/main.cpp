//////////////////////////////////////////////////////////////////////////////
// Praktikum Informatik 1 MMXXIV
// Versuch 04: Einführung Klasse
//
// Datei:  main.cpp
// Inhalt: Hauptprogramm
//////////////////////////////////////////////////////////////////////////////

#include "Vektor.h"
#define ERDRADIUS 6371

using std::cout;
using std::endl;




int main()
{
//    Vektor vector1(1, 0, 0);
//    Vektor vector2(0, 1, 0);
//
//    vector1.ausgabe();
//    vector2.ausgabe();
//
//    cout << "Länge der Vektoren V_1(1,0,0) und V_2(0,1,0):" << endl;
//    cout << vector1.laenge() << endl;
//    cout << vector2.laenge() << endl << endl;
//
//    Vektor vecsca1(1,0,2);
//	Vektor vecsca2(-2,0,1);
//
//	cout << "Skalarprodukt von V_1(1,0,2) und V_2(-2,0,1):" << endl;
//	cout << vecsca1.skalarProd(vecsca2) << endl;
//
//	Vektor vecwin1(0,1,0);
//	Vektor vecwin2(1,0,0);
//
//	cout << "Winkel zwischen V_1(0,1,0) und V_2(1,0,0):" << endl;
//	cout << vecwin1.winkel(vecwin2) << endl;
//
//	cout << "Subtraktion von V_1(1,0,0) mit V_2(0,1,0):" << endl << endl;
//	(vector1.sub(vector2)).ausgabe();
//	cout << endl;
//
//	Vektor vecrot(1,0,1);
//
//	cout << "Rotiere Vektor um z-Achse:" << endl;
//	(vecrot.rotiereUmZ(3));
//	vecrot.ausgabe();

	// Geguckt, ob Funktionen funktionieren

	/*------------------------------------------------------------------------------------*/

	double rad=0;
	int steps;

	Vektor human(0, ((557.4/1000)+ERDRADIUS), 0);
	Vektor earth(0,ERDRADIUS,0);
	Vektor distance = earth.sub(human);


	for(int i=0; earth.skalarProd(distance)!=0;i++)
	{
		rad +=  0.00001;
		earth.rotiereUmZ(rad);
		distance = earth.sub(human);
		steps = i;
	}

	double distanceNumber = distance.laenge();

	std::cout << "Der Horizont ist nach " << distanceNumber << " nicht mehr zu erkennen." << std:: fixed << std::endl;








    return 0;

}
